import { Card } from 'antd'
import React from 'react'

const HomePage = () => {
  return (
    <div className="container mt-5">
      <Card>
        <h2>Netlify auto build when push to main branch github</h2>
      </Card>
    </div>
  )
}

export default HomePage
